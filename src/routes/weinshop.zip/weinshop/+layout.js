import CategoryAPI from '$lib/boilerplate/libraries/xioni-shop/categories'
import CartAPI from '$lib/boilerplate/libraries/xioni-shop/cart'
import InfoAPI from '$lib/boilerplate/libraries/xioni-shop/info'
import { writable } from 'svelte/store'

const module = 990
const basePath = '/weinshop/'

const CART = writable(null, function (set) {
	CartAPI(module, fetch).get(set)
})

export function load({ fetch }) {
	try {
		return {
			info: InfoAPI(module, fetch).get(),
			categories: CategoryAPI(module, fetch).getAll(),
			CART,
			basePath,
			module
		}
	} catch (error) {
		console.error(error)
		return {}
	}
}
