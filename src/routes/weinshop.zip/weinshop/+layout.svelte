<script>
	import Select from '$lib/boilerplate/components/Select/Select.svelte'
	import '$lib/boilerplate/styles/style.scss'
	import '$lib/styles/style.scss'

	export let data

	const { categories, basePath } = data
</script>

<h1 class="$text-center">Mein Weinshop</h1>

<XioniShopNav {categories} {basePath} class="$mb-2" />

<slot />

<style>
	:global(.shop-layout-wrapper) {
		max-width: 1280px;
		margin: 0 auto;
		padding: 2rem;
	}
</style>
