<script lang="ts">
	import type { XioniShopProducts } from '$lib/boilerplate/libraries/xioni-shop/products.types'
	import { makeProductLink } from '$lib/boilerplate/libraries/xioni-shop/utils'

	const products = $$props.data.products as XioniShopProducts
</script>

<Grid tag="ul" gap rowGap>
	{#each products as product}
		<Grid size="1-3" tag="li">
			<XioniShopProductTile {product} link={makeProductLink(product)} />
		</Grid>
	{/each}
</Grid>
