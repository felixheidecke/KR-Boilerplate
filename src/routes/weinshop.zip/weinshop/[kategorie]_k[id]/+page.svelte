<script lang="ts">
	import { makeProductLink } from '$lib/boilerplate/libraries/xioni-shop/utils'

	// --- [ Types ] ---------------------------------------------------------------------------------

	import type { XioniShopCategory } from '$lib/boilerplate/libraries/xioni-shop/categories.types'
	import type { XioniShopProducts } from '$lib/boilerplate/libraries/xioni-shop/products.types'

	// --- [ Props ] ---------------------------------------------------------------------------------

	const products = $$props.data.products as XioniShopProducts
	const category = $$props.data.category as XioniShopCategory
	const basePath = $$props.data.basePath
</script>

<h2 class="$text-center">{category.name}</h2>

<Grid tag="ul" gap rowGap>
	{#each products as product}
		<Grid size="1-3" tag="li">
			<XioniShopProductTile {product} {basePath} link={makeProductLink(basePath, product)} />
		</Grid>
	{/each}
</Grid>
