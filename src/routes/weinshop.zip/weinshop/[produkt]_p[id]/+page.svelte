<script lang="ts">
	// --- [ Types ] ---------------------------------------------------------------------------------

	import type { XioniShopProduct } from '$lib/boilerplate/libraries/xioni-shop/products.types'

	// --- [ Props ] ---------------------------------------------------------------------------------

	export let data

	const product = (data.product as XioniShopProduct) || {}

	// --- [ Logic ] ---------------------------------------------------------------------------------
</script>

<XioniShopProduct {product} />

<Link to="./{product.category?.slug}-c{product.category?.id}" icon="">Zurück</Link>
